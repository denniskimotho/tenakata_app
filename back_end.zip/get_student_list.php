<?php
    include 'db_connect.php';

$email = "";
$result = array();
$result['data'] = array();
   
    
    $sql = "select * from tenakata_tbl order by adm_score desc";

$response = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_array($response)){
        $index['name'] = $row['f_name']." ".$row['l_name'];
        $index['gender'] = $row['gender'];
        $index['age'] = $row['age'];
        $index['iq'] = $row['iq'];
        $index['marital_status'] = $row['marital_status'];
        $index['gps_location'] = $row['latitude'].",".$row['longitude'];
        $index['adm_score'] = $row['adm_score'];
        $index['photo_url'] = $row['photo_url'];

        array_push($result['data'],$index); 
    }
    mysqli_close($conn);
    $result["success"]="1";


    echo json_encode($result);
?>