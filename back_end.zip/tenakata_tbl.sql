-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 22, 2024 at 10:04 AM
-- Server version: 10.6.18-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mwalimubiashara_prototype_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tenakata_tbl`
--

CREATE TABLE `tenakata_tbl` (
  `id` int(11) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `iq` int(11) NOT NULL,
  `marital_status` varchar(13) NOT NULL,
  `longitude` float NOT NULL,
  `latitude` float NOT NULL,
  `adm_score` decimal(7,3) NOT NULL,
  `photo_url` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tenakata_tbl`
--

INSERT INTO `tenakata_tbl` (`id`, `f_name`, `l_name`, `gender`, `age`, `iq`, `marital_status`, `longitude`, `latitude`, `adm_score`, `photo_url`) VALUES
(1, 'Hastie', 'Britcher', 'Male', 2, 148, 'Divorced', 8.895, 36.3277, '4.000', 'https://robohash.org/autemminimaexcepturi.png?size=50x50&set=set1'),
(2, 'Marcella', 'Mauchline', 'Female', 41, 148, 'Divorced', 27.9073, -28.8954, '3.000', 'https://robohash.org/etillumdeserunt.png?size=50x50&set=set1'),
(3, 'Bobbee', 'Augustin', 'Female', 19, 48, 'Divorced', 36.8219, -1.29207, '4.000', 'https://robohash.org/aspernaturnonullam.png?size=50x50&set=set1'),
(4, 'Kirby', 'Keasy', 'Female', 8, 172, 'Married', 13.163, 50.0919, '2.000', 'https://robohash.org/quisitnesciunt.png?size=50x50&set=set1'),
(5, 'Spike', 'Pendlenton', 'Male', 87, 119, 'Married', 14.35, -7.79887, '1.000', 'https://robohash.org/quasutsit.png?size=50x50&set=set1'),
(6, 'Petr', 'Catlin', 'Male', 56, 178, 'Single', 20.0821, 45.1365, '2.000', 'https://robohash.org/siteaimpedit.png?size=50x50&set=set1'),
(7, 'Karrah', 'Careless', 'Female', 3, 140, 'Single', 14.734, 7.75778, '4.000', 'https://robohash.org/liberovoluptateset.png?size=50x50&set=set1'),
(8, 'Elvyn', 'McIlvaney', 'Male', 15, 78, 'Married', -1.28213, 47.0799, '1.000', 'https://robohash.org/nihilundevel.png?size=50x50&set=set1'),
(9, 'Eydie', 'Colles', 'Female', 23, 7, 'Widowed', 27.0352, -31.3699, '1.000', 'https://robohash.org/reprehenderitestin.png?size=50x50&set=set1'),
(10, 'Isa', 'Morrell', 'Female', 14, 93, 'Divorced', -12.953, 49.1664, '3.000', 'https://robohash.org/fugateneturnam.png?size=50x50&set=set1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tenakata_tbl`
--
ALTER TABLE `tenakata_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tenakata_tbl`
--
ALTER TABLE `tenakata_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
