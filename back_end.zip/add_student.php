<?php
include 'db_connect.php';

 // an array to display response
 $response = array();

  
        	if (isset($_POST['photo_url'],$_POST['str_fname'],$_POST['str_lname'],$_POST['str_age'],$_POST['str_iq'],$_POST['marital_status'],$_POST['gender'],$_POST['adm_score',$_POST['str_latitude'],$_POST['str_longitude']])) {

	
		$photo_url = htmlspecialchars($_POST['photo_url']);
        $str_fname = htmlspecialchars($_POST['str_fname']);
        $str_lname = htmlspecialchars($_POST['str_lname']);
        $str_age = htmlspecialchars($_POST['str_age']);
        $str_iq = htmlspecialchars($_POST['str_iq']);
        $marital_status = htmlspecialchars($_POST['marital_status']);
        $gender = htmlspecialchars($_POST['gender']);
        $adm_score = htmlspecialchars($_POST['adm_score']);
        $latitude = htmlspecialchars($_POST['str_latitude']);
        $longitude= htmlspecialchars($_POST['str_longitude']);
 
	 

    $sql = "INSERT INTO `tenakata_tbl`(`f_name`, `l_name`, `gender`, `age`, `iq`, `marital_status`, `longitude`, `latitude`, `adm_score`, `photo_url`)
     VALUES ('$str_fname','$str_lname','$gender',$str_age,$str_iq,'$marital_status','$longitude','$latitude','$adm_score')";							
										
		if (($conn->query($sql) === TRUE)) {

                   
            $response['error'] = false;
            $response['message'] = "Student added successfully!";

        }else {	
            
            $response['error'] = true;
            $response['message'] = "Failed to add student";
            // $msg="Failed to update changes";						
                //echo "Error: " . $sql . "<br>" . $conn->error;	
        }	
								

                $conn->close();
       
    }else{

        $response['error'] = true;
        $response['message'] = "Error";
    }
echo json_encode($response);