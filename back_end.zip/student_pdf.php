<?php
namespace Dompdf;
use Dompdf\Options;
require_once 'dompdf/autoload.inc.php';
include 'db_connect.php';


$HtmlLoaded = '<html> <head>';

$HtmlLoaded .= '

  <style>
table, td, th {
  
}

td, th {
   
  padding: 2px;
  text-align: left;
  font-size:13px;
}
p{
    font-size:14px;
}
table {
  
  border-collapse: collapse;
}

#customers {

  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 3px;
  font-size:12px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 8px;
  padding-bottom: 8px;
  text-align: left;
  background-color: #053d59;
  color: white;
}
 #customers tfoot{
    padding-top: 5px;
    padding-bottom: 5px;
    text-align: center;
    font-weight: bold;
    background-color: #148c44;
    color: white;
    font-size:13px;
 }
 #customers td.title  {
  padding: 5px;
  font-size:13px;
  text-align: center;
  font-weight: bold;
  color:#148c44;
}

.title  {
  padding: 5px;
  font-size:17px;
  text-align: center;
  font-weight: bold;
  color: #053d59;
}

.footer_p{
    font: 11px/10px Georgia, serif;
    font-size:11px;
    padding: 2px;
    color: #053d59;     
}
.page_break { page-break-before: always; }
 
footer {
        position: fixed; 
        bottom: 2px; 
        left: 2px; 
        right: 2px;
        height: 4px; 
        border-radius: 5px;
        background-color: #da1708; 
        text-align: center;
        line-height: 2px;
    }
</style>
    </head>
    <body>
           
    <footer>
        <p class = "footer_p">
           
            Tenakata University, Scaling the heights of education
        </p>
   </footer>   
   <table  border=0 align=center width=30%>
            <tr>
                <td style ="text-align: center; color: #053d59">
                <img src = "img/tenakata_logo.png" style="width: 100px; height:100px;"/>
                <h2>Tenakata University</h2>
                    <p style ="font-size:16px;">Scaling the heights of education</p>
                </td>
                <td style ="text-align: right;">
                    
                </td>
            </tr>
        </table>
    
';
// if(isset($_POST['submit_val']))
// {
$options = new Options();
$options ->set('chroot',realpath(''));
$options->set('isPhpEnabled', 'true');
$dompdf = new Dompdf($options); 




$colordisplay = $mynetcolordisplay = "#148c44";
// $HtmlLoaded .=$imgpath;


  $sql = "SELECT *
        FROM tenakata_tbl  ORDER BY adm_score desc";
        

    $result = mysqli_query($conn, $sql);
     $HtmlLoaded .='
        <table id = "customers" border=0 align=center width=90%>
            <tr>
                <td colspan="8" class="title" >Student List</th>
                 
            </tr> 
            <tr>
                <th style="width:5%">Photo</th>
                <th style="width:15%">Name</th>
                <th style="width:5%">Gender</th>
                <th style="width:5%">Age</th>
                <th style="width:10%">Location</th>                 
                <th style="width:10%">Marital</th>                 
                <th style="width:10%">IQ</th>                 
                <th style="width:10%">Adm Score</th>                
            </tr>';

    if (mysqli_num_rows($result) > 0) {

                       
		while($row = mysqli_fetch_assoc($result)) {

        $HtmlLoaded .='
            <tr>
                <td> <img src = '.$row["photo_url"].' style="width: 50px; height:50px;"></td>
                <td>'.$row["f_name"].' '.$row["l_name"].'</td>
                <td>'.$row["gender"].'</td>
                <td>'.$row["age"].'</td>
                <td>'.$row["latitude"].','.$row["longitude"].'</td>
                <td>'.$row["marital_status"].'</td>
                <td>'.$row["iq"].'</td>
                <td>'.$row["adm_score"].'</td>
               
            </tr> ';
              }


            }else{
                $HtmlLoaded .='
                    <tr>
                        <td colspan="4" style="text-align:center" >No Data found</td> 
                    </tr> ';
            }
        $HtmlLoaded .='</table>';

       

       
//output the pdf
//  $dompdf->set_option("isPhpEnabled", true);
 $HtmlLoaded .= '
        </body>
    </html>';

    // echo $HtmlLoaded;
$dompdf->loadHtml($HtmlLoaded);
 
$dompdf->setPaper('A4', 'protrait');
$dompdf->render();
// // Instantiate canvas instance
// $canvas = $dompdf->getCanvas();
// $w = $canvas->get_width();
// $h = $canvas->get_height();
// $pageNumberWidth = $w / 2;
// $pageNumberHeight = $h - 50;
 
// // $GLOBALS["logo1"]=public_path('images/logo_bg.png');
// // $GLOBALS["logo2"]=public_path('images/logo_bg.png');
// $canvas->page_script('
// if ($PAGE_NUM > 1) {
//     $current_page = $PAGE_NUM-1;
//     $total_pages = $PAGE_COUNT-1;
//     $font = $fontMetrics->getFont("times", "normal"); 
//     $pdf->set_opacity(1,"Multiply");
//     $pdf->text(297.64, 791.89, "$current_page / $total_pages", $font, 10, array(0,0,0));
     
//     $pdf->set_opacity(0.2,"Multiply");
    
// }
// ');
// $canvas->set_opacity(.5,'Multiply');//Multiply means apply to all pages.
// // Specify watermark text
// $text = " ";
// // Instantiate font metrics class
// $fontMetrics = new FontMetrics($canvas, $options);
// $font = $fontMetrics->getFont('times');
// $txtHeight = $fontMetrics->getFontHeight($font, 150);
// $textWidth = $fontMetrics->getTextWidth($text, $font, 40);
 
// $x = (($w-$textWidth)/2);
// $y = (($h-$txtHeight)/2);
 
// //page_text method applies text to all pages.
// $canvas->page_text($x, $y, $text, $font, 40,$color = array(255,0,0), 
//         $word_space = 0.0, $char_space = 0.0, $angle = 20.0);
return $dompdf->stream('TU_Student_list.pdf', array("Attachment" => 0)); 

// $dompdf->loadHtml($HtmlLoaded);
 
// $dompdf->setPaper('A4', 'protrait');
// $dompdf->render();
// $dompdf->stream("My Networth",array("Attachment" => false));
exit(0); 